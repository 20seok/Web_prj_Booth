
// when document loaded
$(document).ready(function() {
	// sidenav init
	$('.sidenav').sidenav();
	
	// collapsible init
	$('.collapsible').collapsible();

	// select init	
    $('select').formSelect();
    
    // autocomplete init
    $('input.autocomplete').autocomplete({
      data: {
        "Apple": null,
        "Microsoft": null,
        "Google": 'https://placehold.it/250x250'
      },
    });
	
});

