package com.lys.util;

import java.lang.reflect.Type;
import java.sql.Timestamp;

import org.mindrot.jbcrypt.BCrypt;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.lys.domain.MemberVO;

public class MemberDeserializer implements JsonDeserializer<MemberVO> {

	@Override
	public MemberVO deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
			throws JsonParseException {

		MemberVO memberVO = null;
		
		// {} JSonObject, [] JsonArray
		if(json.isJsonObject()) {
			JsonObject jsonObject = json.getAsJsonObject();
			
			memberVO = new MemberVO();
			memberVO.setId(jsonObject.get("id").getAsString());
			memberVO.setPwd(jsonObject.get("pwd").getAsString());
			memberVO.setName(jsonObject.get("name").getAsString());
			memberVO.setBirthday(jsonObject.get("birthday").getAsString());
			memberVO.setGender(jsonObject.get("gender").getAsString());
			memberVO.setEmail(jsonObject.get("email").getAsString());
			memberVO.setRecvEmail(jsonObject.get("recvEmail").getAsString());
			memberVO.setRegDate(new Timestamp(System.currentTimeMillis()));
			
			// 비밀번호 암호화
			String hashedPwd = BCrypt.hashpw(memberVO.getPwd(), BCrypt.gensalt());
			memberVO.setPwd(hashedPwd);
			
			// 생년월일 하이픈 빼기
			String birthday = memberVO.getBirthday();
			birthday = birthday.replace("-", ""); // 하이픈 문자열을 빈문자열로 대체
			memberVO.setBirthday(birthday);
		}
		
		return memberVO;
		
	}
	
}
