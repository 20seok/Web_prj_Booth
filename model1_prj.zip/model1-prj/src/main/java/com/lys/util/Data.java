package com.lys.util;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.Session;

public class Data {
	public static final List<Session> SESSION_LIST = new ArrayList<>();
	
	public static void broadcast(String message) {
		for (Session session : SESSION_LIST) {
			try {
				session.getBasicRemote().sendText(message);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} // for
	}
}
