package com.lys.restapi;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.lys.domain.ReplyVO;
import com.lys.repository.ReplyDAO;

@WebServlet("/api/replys/*")
public class ReplyRestServlet extends HttpServlet {

	private static final String BASE_URI = "/booth/api/replys";

	private ReplyDAO replyDAO = ReplyDAO.getInstance();

	private Gson gson = new Gson();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. "/api/replys" -> reply테이블 전체 레코드 정보 요청
		// 2. "/api/replys/aaa" -> reply테이블에 아이디가 aaa인 레코드 한개 정보 요청
		String requestURI = request.getRequestURI();
		System.out.println("requestURI : " + requestURI);

		String bnum = requestURI.substring(BASE_URI.length());
		System.out.println("bnum = " + bnum.substring(1));

		String strJson = "";
		
		if (bnum.length() != 0) {
		
		bnum = bnum.substring(1);
			
		List<ReplyVO> replyList = replyDAO.getReplys2(bnum);
				
		strJson = gson.toJson(replyList);
		}

		// 클라이언트 쪽으로 출력하기
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(strJson);
		out.flush();

	} // doGet

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// "/api/members"
		String requestURI = request.getRequestURI();
		String bnum = requestURI.substring(BASE_URI.length());
		
		if (bnum.length() != 0) {
			bnum = bnum.substring(1);
		}
		
		replyDAO.insertReply(bnum, request);
		
	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// "/api/members/aaa"

		String requestURI = request.getRequestURI();
		String rnum = requestURI.substring(BASE_URI.length());
		if (rnum.length() != 0) {
			rnum = rnum.substring(1);
		}
		replyDAO.deleteReply(Integer.parseInt(rnum), request);
		
	}
	
}
