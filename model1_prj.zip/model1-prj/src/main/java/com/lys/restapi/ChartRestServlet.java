package com.lys.restapi;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.lys.repository.Board2DAO;

@WebServlet(urlPatterns = "/api/chart/*")
public class ChartRestServlet extends HttpServlet {

	private static final String BASE_URI = "/api/chart";
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String requestURI = request.getRequestURI();
		System.out.println("requestURI : " + requestURI);
		
		String str = requestURI.substring(BASE_URI.length());
		str = str.substring(1);
		System.out.println("str = " + str);
		
		if (str.equals("board-per-count")) {
			printBoardPerCount(request, response);
		}
	} // doGet
	
	private void printBoardPerCount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Board2DAO board2DAO = Board2DAO.getInstance();
		
		List<Map<String, Object>> list = board2DAO.getBoardPerCount();

		// chart.js에서 사용될 수 있도록 데이터를 가공하기
		List<String> labelList = new ArrayList<>(); // 레이블을 담을 리스트 준비
		List<Integer> dataList = new ArrayList<>(); // 데이터를 담을 리스트 준비

		for (Map<String, Object> map : list) {
			labelList.add((String) map.get("codeName"));
			dataList.add((Integer) map.get("cnt"));
		}

		// Gson 객체 준비
		Gson gson = new Gson();

		Map<String, Object> map = new HashMap<>();
		map.put("labelList", labelList);
		map.put("dataList", dataList);
		
		String strJson = gson.toJson(map);
		System.out.println("strJson : " + strJson); // ["남성","여성"]
		
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(strJson);
		out.flush();
	}
	
	  
}
