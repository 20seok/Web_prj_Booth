package com.lys.restapi;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.lys.repository.ReplyDAO;

@WebServlet("/api/replys2/*")
public class ReplyRestServlet2 extends HttpServlet {

	private static final String BASE_URI = "/booth/api/replys2";

	private ReplyDAO replyDAO = ReplyDAO.getInstance();

	private Gson gson = new Gson();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		

	} // doGet

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// "/api/members"
		String requestURI = request.getRequestURI();
		String rnum = requestURI.substring(BASE_URI.length());
		
		if (rnum.length() != 0) {
			rnum = rnum.substring(1);
		}
		
		replyDAO.updateReply(Integer.parseInt(rnum), request);
		
	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
	}
	

}
