package com.lys.domain;

import lombok.Data;

@Data
public class CodesVO {
	
	private String code;
	private String mid;
	
}
