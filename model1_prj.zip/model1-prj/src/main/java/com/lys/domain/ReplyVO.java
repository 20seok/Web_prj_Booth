package com.lys.domain;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import lombok.Data;

@Data
public class ReplyVO {
	
	private Integer rnum;
	private Integer bnum;
	private String mid;
	private String content;
	private Timestamp regDate;
	private String dummy;
	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String strDate = sdf.format(regDate);
		
		StringBuilder builder = new StringBuilder();
		builder.append("ReplyVO [rnum=")
		.append(rnum).append(", bnum=")
		.append(bnum).append(", mid=")
		.append(mid)
		.append(", content=")
		.append(content)
		.append(", regDate=")
		.append(strDate)
		.append("]");
		return builder.toString();
	}
	
	
	
}
