package com.lys.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.lys.domain.BoardVO;
import com.lys.domain.CodesVO;
import com.lys.domain.Criteria;

public class CodesDAO {
	
	// 싱글톤
	private static CodesDAO instance;
	
	public static CodesDAO getInstance() {
		if (instance == null) {
			instance = new CodesDAO();
		}
		return instance;
	}

	// 생성자를 private로 해서 외부로부터 숨김
	private CodesDAO() {
	}
	
	// 주글 쓰기
	public void addCode(CodesVO codesVO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql += "insert into codes (code, mid) ";
			sql += "values (?, ?) ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, codesVO.getCode());
			pstmt.setString(2, codesVO.getMid());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	} // addCode
	
	// 코드 가져오기
	public String getCode(String code) {
		String isCode = "";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql += "select code from codes where code = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				isCode = rs.getString("code");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return isCode;
	}
	
	
}
