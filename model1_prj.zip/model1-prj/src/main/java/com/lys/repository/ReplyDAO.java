package com.lys.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.lys.domain.ReplyVO;

public class ReplyDAO {

	// 싱글톤
	private static ReplyDAO instance;
	
	public static ReplyDAO getInstance() {
		if (instance == null) {
			instance = new ReplyDAO();
		}
		return instance;
	}
	
	// 생성자를 private로 해서 외부로부터 숨김
	private ReplyDAO() {
	}
	
	// 댓글 불러오기
	public ReplyVO getReplys(String bnum) {
		ReplyVO replyVO = null;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql = "select * from reply2 where bnum = ? order by rnum desc";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bnum);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				replyVO = new ReplyVO();
				replyVO.setRnum(rs.getInt("rnum"));
				replyVO.setBnum(rs.getInt("bnum"));
				replyVO.setMid(rs.getString("mid"));
				replyVO.setContent(rs.getString("content"));
				replyVO.setRegDate(rs.getTimestamp("reg_date"));
				
			} // while
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return replyVO;
		
	} // getReplys
	
	// 댓글 불러오기
	public List<ReplyVO> getReplys2(String bnum) {
		List<ReplyVO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql = "select rnum, bnum, mid, content, if(now() - reg_date < 600, '방금전✨', reg_date) as reg_date from reply2 where bnum = ? order by rnum desc";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bnum);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				ReplyVO replyVO = new ReplyVO();
				replyVO.setRnum(rs.getInt("rnum"));
				replyVO.setBnum(rs.getInt("bnum"));
				replyVO.setMid(rs.getString("mid"));
				replyVO.setContent(rs.getString("content"));
				//replyVO.setRegDate(rs.getTimestamp("reg_date"));
				replyVO.setDummy(rs.getString("reg_date"));
				
				list.add(replyVO);
				
			} // while
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
		
	} // getReplys
		
		public void insertReply(String bnum, HttpServletRequest request) {
			
			HttpSession session = request.getSession();
			String writer = (String) session.getAttribute("id");
			String content = request.getParameter("content");
			
			Connection con = null;
			PreparedStatement pstmt = null;
			
			try {
				con = JdbcUtils.getConnection();
				
				String sql = "INSERT INTO REPLY2(bnum, mid, content, reg_date) VALUES(?,?,?,NOW())";
				
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, bnum);
				pstmt.setString(2, writer);
				pstmt.setString(3, content);
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtils.close(con, pstmt);
			}
		} // insertReply
		
		public void deleteReply(int rnum, HttpServletRequest request) {
			Connection con = null;
			PreparedStatement pstmt = null;
			
			try {
				con = JdbcUtils.getConnection();
				
				String sql = "delete from reply2 where rnum = ? ";
				
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, rnum);
				
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtils.close(con, pstmt);
			}
		} // deleteReply
		
		public void deleteReplyByBno(int bnum) {
			Connection con = null;
			PreparedStatement pstmt = null;
			
			try {
				con = JdbcUtils.getConnection();
				
				String sql = "delete from reply2 where bnum = ? ";
				
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, bnum);
				
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtils.close(con, pstmt);
			}
		} // deleteReplyByBno
		
		public void updateReply(int rnum, HttpServletRequest request) {
			String content = request.getParameter("content");

			System.out.println("rnum : " + rnum);
			System.out.println("content : " + content);
			
			Connection con = null;
			PreparedStatement pstmt = null;
			
			try {
				con = JdbcUtils.getConnection();
				
				String sql = "update reply2 set content = ? where rnum = ? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, content);
				pstmt.setInt(2, rnum);
				
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtils.close(con, pstmt);
			}
		}
		
}
