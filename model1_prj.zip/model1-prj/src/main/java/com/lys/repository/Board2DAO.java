package com.lys.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.lys.domain.Board2VO;
import com.lys.domain.BoardVO;
import com.lys.domain.Criteria;

public class Board2DAO {
	
	// 싱글톤
	private static Board2DAO instance;
	
	public static Board2DAO getInstance() {
		if (instance == null) {
			instance = new Board2DAO();
		}
		return instance;
	}

	// 생성자를 private로 해서 외부로부터 숨김
	private Board2DAO() {
	}
	
	// board 테이블 모든 레코드 삭제
	public void deleteAll() {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "delete from board2";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	} // deleteAll
	
	// 게시글 삭제
	public void deleteContentByNum(int num) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "delete from board2 where num = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
		
	} // deleteContentByNum
	
	// 전체 글 개수 가져오기
	public int getCountAll() {
		int count = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();

			String sql = "select count(*) as cnt from board2";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt("cnt"); // 별칭으로 가져옴
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return count;
	} // getCountAll
	
	// 전체 글 개수 가져오기
	public int getCountAllByCode(String code) {
		int count = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "select count(*) as cnt from board2 where code = ?";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt("cnt"); // 별칭으로 가져옴
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return count;
	} // getCountAll
	
	// 전체 글 개수 가져오기
	public int getCountAllById(String id) {
		int count = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "select count(*) as cnt from board2 where mid = ?";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt("cnt"); // 별칭으로 가져옴
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return count;
	} // getCountAll
	
	// 전체 글 개수 가져오기
	public int getCountBySearch(Criteria cri) {
		int count = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();

			String sql = "";
			sql = "select count(*) as cnt ";
			sql += "from board2 ";
			
			if (cri.getType().length() > 0) {
				sql += "where " + cri.getType() + " like ? ";
			}
			
			pstmt = con.prepareStatement(sql); // 문장객체 준비
			
			if (cri.getType().length() > 0) {
				pstmt.setString(1, "%" + cri.getKeyword() + "%");
			}
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt("cnt"); // 별칭으로 가져옴
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return count;
	} // getCountBySearch
	
	// select ifnull(max(num), 0) + 1 as nextnum from board2;
	public int getNextnum() {
		int num = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();

			String sql = "select ifnull(max(num), 0) + 1 as nextnum from board2";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				num = rs.getInt("nextnum"); // 별칭으로 가져옴
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return num;
	} // getNextnum
	
	// 주글 쓰기
	public void addBoard(Board2VO board2VO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql += "insert into board2 (num, mid, subject, content, readcount, reg_date, ipaddr, re_ref, re_lev, re_seq, code) ";
			sql += "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, board2VO.getNum());
			pstmt.setString(2, board2VO.getMid());
			pstmt.setString(3, board2VO.getSubject());
			pstmt.setString(4, board2VO.getContent());
			pstmt.setInt(5, board2VO.getReadcount());
			pstmt.setTimestamp(6, board2VO.getRegDate());
			pstmt.setString(7, board2VO.getIpaddr());
			pstmt.setInt(8, board2VO.getReRef());
			pstmt.setInt(9, board2VO.getReLev());
			pstmt.setInt(10, board2VO.getReSeq());
			pstmt.setString(11, board2VO.getCode());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	} // adBoard
	
	// 글 전체 리스트로 가져오기
	public List<Board2VO> getBoards(String code) {
		List<Board2VO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql = "select * ";
			sql += "from board2 ";
			sql += "where code = " + code;
			sql += " order by re_ref desc, re_seq asc ";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board2VO board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
				
				list.add(board2VO);
			} // while
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getBoards
	
	// 내가 작성한 글 가져오기
	public List<Board2VO> getMyBoards(String id) {
		List<Board2VO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "select * from board2 where mid = ? order by re_ref desc, re_seq asc ";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board2VO board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(id);
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
				
				list.add(board2VO);
			} // while
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getMyBoards
	
	public Board2VO getBoardByNum(int num) {
		Board2VO board2VO = null;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = ""; 
			sql += "select * ";
			sql += "from board2 ";
			sql += "where num = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
			} // if
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return board2VO;
	} // getBoard
	
	// 글 전체 리스트로 가져오기
	public List<Board2VO> getBoardsForAdmin() {
		List<Board2VO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql = "select * ";
			sql += "from board2 ";
			sql += "order by num desc ";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board2VO board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
				
				list.add(board2VO);
			} // while
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getBoardsForAdmin
	
	// 글 전체리스트로 가져오기
	public List<Board2VO> getBoardsCri(Criteria cri) {
		List<Board2VO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		// 한 페이지당 글개수가 10개씩 일때
		// 1 페이지 -> 0
		// 2 페이지 -> 10
		// 3 페이지 -> 20
		// 4 페이지 -> 30
		
		// 시작 행 번호 (MySQL의 LIMIT절의 시작 행 번호)
		int startRow = (cri.getPageNum() -1) * cri.getAmount();
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = ""; 
			sql += "select num, mid, subject, content, readcount, if(now() - reg_date < 600, '방금전', reg_date) as reg_date, ipaddr, re_ref, re_lev, re_seq, code ";
			sql += "from board2 ";
			sql += "where code = ? ";
			if (!cri.getType().equals("")) { // cri.getType().length() > 0
				sql += " and " + cri.getType() + " like ? ";				
			}
			sql += "order by re_ref desc, re_seq asc ";
			sql += "limit ?, ? ";
			
			pstmt = con.prepareStatement(sql);
			
			if (!cri.getType().equals("")) { // cri.getType().length() > 0
				pstmt.setString(1, cri.getCode());
				pstmt.setString(2, "%" + cri.getKeyword() + "%");
				pstmt.setInt(3, startRow);
				pstmt.setInt(4, cri.getAmount());				
			} else {
				pstmt.setString(1, cri.getCode());
				pstmt.setInt(2, startRow);
				pstmt.setInt(3, cri.getAmount());
			}
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board2VO board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setDummy(rs.getString("reg_date"));
				//board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
				
				list.add(board2VO);
			} // while
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getBoards
	
	// 글 전체리스트로 가져오기(크리테리아, 아이디)
	public List<Board2VO> getBoardsCri(Criteria cri, String id) {
		List<Board2VO> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		// 한 페이지당 글개수가 10개씩 일때
		// 1 페이지 -> 0
		// 2 페이지 -> 10
		// 3 페이지 -> 20
		// 4 페이지 -> 30
		
		// 시작 행 번호 (MySQL의 LIMIT절의 시작 행 번호)
		int startRow = (cri.getPageNum() -1) * cri.getAmount();
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = ""; 
			sql += "select * ";
			sql += "from board2 ";
			sql += "where mid = ? ";
			if (!cri.getType().equals("")) { // cri.getType().length() > 0
				sql += " and " + cri.getType() + " like ? ";				
			}
			sql += "order by re_ref desc, re_seq asc ";
			sql += "limit ?, ? ";
			
			pstmt = con.prepareStatement(sql);
			
			if (!cri.getType().equals("")) { // cri.getType().length() > 0
				pstmt.setString(1, id);
				pstmt.setString(2, "%" + cri.getKeyword() + "%");
				pstmt.setInt(3, startRow);
				pstmt.setInt(4, cri.getAmount());				
			} else {
				pstmt.setString(1, id);
				pstmt.setInt(2, startRow);
				pstmt.setInt(3, cri.getAmount());
			}
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board2VO board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
				
				list.add(board2VO);
			} // while
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getBoards(cri, id)
	
//	// 글 전체리스트로 가져오기
//	public List<Board2VO> getBoardsCri(Criteria cri) {
//		List<Board2VO> list = new ArrayList<>();
//		
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		// 한 페이지당 글개수가 10개씩 일때
//		// 1 페이지 -> 0
//		// 2 페이지 -> 10
//		// 3 페이지 -> 20
//		// 4 페이지 -> 30
//		
//		// 시작 행 번호 (MySQL의 LIMIT절의 시작 행 번호)
//		int startRow = (cri.getPageNum() -1) * cri.getAmount();
//		
//		try {
//			con = JdbcUtils.getConnection();
//			
//			String sql = ""; 
//			sql += "select * ";
//			sql += "from board2 ";
//			sql += "where code = ? ";
//			if (!cri.getType().equals("")) { // cri.getType().length() > 0
//				sql += " and " + cri.getType() + " like ? ";				
//			}
//			sql += "order by re_ref desc, re_seq asc ";
//			sql += "limit ?, ? ";
//			
//			pstmt = con.prepareStatement(sql);
//			
//			if (!cri.getType().equals("")) { // cri.getType().length() > 0
//				pstmt.setString(1, cri.getCode());
//				pstmt.setString(2, "%" + cri.getKeyword() + "%");
//				pstmt.setInt(3, startRow);
//				pstmt.setInt(4, cri.getAmount());				
//			} else {
//				pstmt.setString(1, cri.getCode());
//				pstmt.setInt(2, startRow);
//				pstmt.setInt(3, cri.getAmount());
//			}
//			
//			rs = pstmt.executeQuery();
//			
//			while (rs.next()) {
//				Board2VO board2VO = new Board2VO();
//				board2VO.setNum(rs.getInt("num"));
//				board2VO.setMid(rs.getString("mid"));
//				board2VO.setSubject(rs.getString("subject"));
//				board2VO.setContent(rs.getString("content"));
//				board2VO.setReadcount(rs.getInt("readcount"));
//				board2VO.setRegDate(rs.getTimestamp("reg_date"));
//				board2VO.setIpaddr(rs.getString("ipaddr"));
//				board2VO.setReRef(rs.getInt("re_ref"));
//				board2VO.setReLev(rs.getInt("re_lev"));
//				board2VO.setReSeq(rs.getInt("re_seq"));
//				board2VO.setCode(rs.getString("code"));
//				
//				list.add(board2VO);
//			} // while
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			JdbcUtils.close(con, pstmt, rs);
//		}
//		return list;
//	} // getBoards
	
	public Board2VO getBoard(int num) {
		Board2VO board2VO = null;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = ""; 
			sql += "select * ";
			sql += "from board2 ";
			sql += "where num = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				board2VO = new Board2VO();
				board2VO.setNum(rs.getInt("num"));
				board2VO.setMid(rs.getString("mid"));
				board2VO.setSubject(rs.getString("subject"));
				board2VO.setContent(rs.getString("content"));
				board2VO.setReadcount(rs.getInt("readcount"));
				board2VO.setRegDate(rs.getTimestamp("reg_date"));
				board2VO.setIpaddr(rs.getString("ipaddr"));
				board2VO.setReRef(rs.getInt("re_ref"));
				board2VO.setReLev(rs.getInt("re_lev"));
				board2VO.setReSeq(rs.getInt("re_seq"));
				board2VO.setCode(rs.getString("code"));
			} // if
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return board2VO;
	} // getBoard
	
	// 조회수 1 증가시키는 메소드
	public void updateReadcount(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql += "update board2 ";
			sql += "set readcount = readcount + 1 ";
			sql += "where num = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
		
	} // updateReadcount
	
	// 게시글 수정하기
	public void updateBoard(Board2VO board2VO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql += "update board2 ";
			sql += "set subject = ?, content = ?, ipaddr = ? ";
			sql += "where num = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, board2VO.getSubject());
			pstmt.setString(2, board2VO.getContent());
			pstmt.setString(3, board2VO.getIpaddr());
			pstmt.setInt(4, board2VO.getNum());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
		
	} // updateReadcount

	// 답글등록
	public void updateReSeqAndAddReply(Board2VO board2VO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = JdbcUtils.getConnection();
			// 수동커밋으로 변경 (기본값은 자동커밋)
			con.setAutoCommit(false);
			
			// 답글을 다는 대상글과 같은 글그룹 내에서
			// 답글을 다는 대상글의 그룹내 순번보다 큰 글들의 순번을 1씩 증가시킴
			String sql = "";
			sql = "update board2 ";
			sql += "set re_seq = re_seq + 1 ";
			sql += "where re_ref = ? ";
			sql += "and re_seq > ? ";
			
			pstmt = con.prepareStatement(sql); // update문을 가진 문장객체
			pstmt.setInt(1, board2VO.getReRef());
			pstmt.setInt(2, board2VO.getReSeq());
			pstmt.executeUpdate(); // update문을 가진 문장객체 실행하기
			pstmt.close(); // update문을 가진 문장객체 닫기
			
			// 답글쓰기
			sql = "insert into board2 (num, mid, subject, content, readcount, reg_date, ipaddr, re_ref, re_lev, re_seq, code) ";
			sql += "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, board2VO.getNum());
			pstmt.setString(2, board2VO.getMid());
			pstmt.setString(3, board2VO.getSubject());
			pstmt.setString(4, board2VO.getContent());
			pstmt.setInt(5, board2VO.getReadcount());
			pstmt.setTimestamp(6, board2VO.getRegDate());
			pstmt.setString(7, board2VO.getIpaddr());
			// re값은 insert될 답글정보로 수정하기
			pstmt.setInt(8, board2VO.getReRef()); // 답글의 글그룹번호는 답글다는 대상글의 글그룹번호와 동일
			pstmt.setInt(9, board2VO.getReLev() + 1); // 답글의 레벨은 답글다는 대상글의 레벨값 + 1
			pstmt.setInt(10, board2VO.getReSeq() + 1); // 답글의 레벨은 답글다는 대상글의 순번값 + 1
			pstmt.setString(11, board2VO.getCode());
			
			pstmt.executeUpdate();
			
			con.commit(); // 커밋하기
			
			con.setAutoCommit(true); // 기본값이었던 자동커밋으로 설정 되돌리기
			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback(); // 트랜잭션 단위작업에 문제가 생기면 롤백
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	} // updateReSeqAndAddReply
	
	
	public JSONArray replyLoad(HttpServletRequest request, HttpServletResponse response) {
		JSONArray list = new JSONArray();
		JSONObject json = new JSONObject();
		
		String boardNo = request.getParameter("boardNo");
		int cntReply = 0;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "SELECT * FROM REPLY WHERE BOARDNO = " + boardNo;
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				json = null;
				json = new JSONObject();
				json.put("replyNo", rs.getString("replyNo"));
				json.put("writer", rs.getString("writer"));
				json.put("content", rs.getString("content"));
				json.put("regdate", rs.getString("regdate"));
				list.add(json);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		
		return list;
	}
	
	public void replyInsert(HttpServletRequest request) {
		HttpSession session = request.getSession();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		String writer = (String) session.getAttribute("id");
		String content = request.getParameter("content");
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "INSERT INTO REPLY(boardNo, writer, content, regdate) VALUES(?,?,?,NOW())";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, boardNo);
			pstmt.setString(2, writer);
			pstmt.setString(3, content);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	}
	
	public void replyDelete(HttpServletRequest request) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int replyNo = Integer.parseInt(request.getParameter("replyNo"));
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "DELETE FROM REPLY WHERE boardNo = ? AND replyNo = ?";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, boardNo);
			pstmt.setInt(2, replyNo);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	}
	
	public void replyUpdate(HttpServletRequest request) {
		HttpSession session = request.getSession();
		
		Connection con = null;
		PreparedStatement pstmt = null;

		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int replyNo = Integer.parseInt(request.getParameter("replyNo"));
		String writer = (String) session.getAttribute("id");
		String content = request.getParameter("content");
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "UPDATE REPLY SET CONTENT = ? WHERE boardNo = ? AND replyNo = ? AND writer = ?";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, content);
			pstmt.setInt(2, boardNo);
			pstmt.setInt(3, replyNo);
			pstmt.setString(4, writer);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt);
		}
	} // replyUpdate
	
	//차트
	public List<Map<String, Object>> getBoardPerCount() {
		List<Map<String, Object>> list = new ArrayList<>();
		
		Connection con = null; // 접속
		PreparedStatement pstmt = null; // sql문장객체 타입
		ResultSet rs = null;
		
		try {
			con = JdbcUtils.getConnection();
			
			String sql = "";
			sql  = "select code, count(*) as cnt from board2 group by code order by cnt desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Map<String, Object> map = new HashMap<>(); // VO 객체 대용으로 사용
				map.put("codeName", rs.getString("code"));
				map.put("cnt", rs.getInt("cnt"));
				
				list.add(map);
			} // while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(con, pstmt, rs);
		}
		return list;
	} // getBoardPerCount
	
	
}
